# frontend/streamlit_app.py
import streamlit as st
import requests
import os
from dotenv import load_dotenv

load_dotenv()

API_URL = os.getenv("API_URL", "http://127.0.0.1:8000")

st.set_page_config(page_title="Insurance FAQ RAG Assistant", layout="wide")

# --- Custom Gradient Header ---
st.markdown(
    """
    <div style='background: linear-gradient(90deg, #2c3e50 0%, #2980b9 100%); padding: 1.5rem 0; border-radius: 10px; text-align: center; color: white; margin-bottom: 2rem;'>
        <h1 style='margin-bottom: 0.2em; font-size: 2.5em;'>Insurance FAQ RAG Assistant</h1>
        <p style='margin-top: 0; font-size: 1.2em;'>AI-powered answers with citations</p>
    </div>
    """, unsafe_allow_html=True
)

# --- Sidebar ---
st.sidebar.title("Settings & Ingest FAQs")
st.sidebar.info("Upload your FAQ CSV and ask insurance questions. Powered by Groq LLM and semantic search.")
uploaded = st.sidebar.file_uploader("Upload CSV (id,question,answer)", type=["csv"])
if uploaded:
    files = {"file": (uploaded.name, uploaded.getvalue(), "text/csv")}
    resp = requests.post(f"{API_URL}/ingest_csv", files=files)
    st.sidebar.write(resp.json())
elif st.sidebar.button("Ingest bundled faqs.csv"):
    resp = requests.post(f"{API_URL}/ingest_default")
    st.sidebar.write(resp.json())

# --- Main Layout ---
with st.container():
    st.subheader("Ask a Question")
    query = st.text_area("Your question", "", height=80)
    k = st.slider("Top K retrieved docs", 1, 6, 3)
    col1, col2, col3 = st.columns([5, 1, 5])
    with col2:
        ask_btn = st.button("  Ask  ")  # Remove use_container_width for default button size
    if ask_btn and query.strip():
        payload = {"query": query, "top_k": k}
        with st.spinner("Generating answer..."):
            resp = requests.post(f"{API_URL}/query", json=payload, timeout=120)
            if resp.status_code == 200:
                data = resp.json()
                st.success("Answer generated!")
                st.markdown("### Answer")
                st.write(data["answer"])
                st.markdown("### Retrieved source snippets")
                for d in data["retrieved"]:
                    with st.expander(f"FAQ#{d['id']} (score: {d['score']:.3f})"):
                        st.write(f"**Q:** {d['question']}")
                        st.write(f"**A:** {d['answer']}")
            else:
                st.error(f"Error: {resp.status_code} - {resp.text}")

# --- Footer ---
st.markdown(
    """
    <hr>
    <div style='text-align: center; color: #888; font-size: 0.95em; margin-top: 2em;'>
        © 2025 Insurance FAQ RAG Assistant | Powered by Streamlit & GitHub Copilot
    </div>
    """, unsafe_allow_html=True
)
