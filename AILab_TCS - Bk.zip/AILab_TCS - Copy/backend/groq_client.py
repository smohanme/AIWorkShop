import os
from dotenv import load_dotenv
import requests

class GroqClient:
    def __init__(self):
        # Always load environment variables
        load_dotenv()

        self.api_key = os.getenv("GROQ_API_KEY")
        self.header_value = os.getenv("GROQ_HEADER_VALUE")
        self.api_url = os.getenv("GROQ_API_URL")
        self.index_dir = os.getenv("INDEX_DIR", "./index_store")

        if not self.api_key:
            raise ValueError("GROQ_API_KEY not set in environment")

        self.headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "X-Request-Source": self.header_value or "Default-Source"
        }

    def chat_completion(self, messages, model="llama-3.3-70b-versatile"):
        payload = {
            "model": model,
            "messages": messages
        }
        response = requests.post(self.api_url, headers=self.headers, json=payload)
        response.raise_for_status()
        return response.json()["choices"][0]["message"]["content"]
