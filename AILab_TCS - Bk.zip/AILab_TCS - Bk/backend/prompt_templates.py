# backend/prompt_templates.py
from typing import List, Dict

SYSTEM_PROMPT = """You are an Insurance FAQ Assistant. Use ONLY the provided FAQ snippets to answer the user's question. 
If the answer cannot be determined from the snippets, respond with: "I don't know based on the FAQ provided." 
Always include citations to the FAQ snippet(s) used in square brackets like [FAQ#<id>] at the end of the sentence that used the fact.
Do not hallucinate. Provide a detailed, elaborate explanation using the FAQ snippets, and include examples or context if available.
Include a "Sources:" list at the end with the source lines.
"""

def build_prompt(user_query: str, retrieved_docs: List[Dict]) -> list:
    # build a single user message containing the query and the collected snippets
    combined_snippets = ""
    for d in retrieved_docs:
        combined_snippets += f"[FAQ#{d['id']}] Q: {d['question']}\nA: {d['answer']}\n\n"

    user_content = f"""User question: {user_query}

Here are relevant FAQ snippets (use them only):
{combined_snippets}

Instructions:
- Answer the user's question using only the text above.
- Add inline citation(s) like [FAQ#2] after factual statements drawn from snippets.
- Provide a detailed, elaborate explanation using the FAQ snippets, and include examples or context if available around one line.
- Also give detailed explanation with real examples at least one line.
- Provide a short "Sources:" list with FAQ ids and the corresponding source string.
- If unable to answer from the snippets, say: "I don't know based on the FAQ provided."
"""

    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": user_content}
    ]
    return messages
