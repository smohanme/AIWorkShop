# index_store/faiss_index_build.py
import os
import pandas as pd
import pickle
import faiss
from sentence_transformers import SentenceTransformer

MODEL_PATH = os.path.join(os.path.dirname(__file__), "..", "backend", "models", "all-MiniLM-L6-v2.pt")
model = SentenceTransformer(MODEL_PATH)

kb_path = os.path.join(os.path.dirname(__file__), "..", "data", "knowledge_base.csv")
kb = pd.read_csv(kb_path)

embeddings = model.encode(kb['Content'].tolist())
dim = embeddings.shape[1]

index = faiss.IndexFlatL2(dim)
index.add(embeddings)

index_file = os.path.join(os.path.dirname(__file__), "faiss.index")
meta_file = os.path.join(os.path.dirname(__file__), "meta.pkl")

faiss.write_index(index, index_file)
with open(meta_file, "wb") as f:
    pickle.dump(kb.to_dict(orient="records"), f)

print("FAISS index and metadata saved successfully!")
