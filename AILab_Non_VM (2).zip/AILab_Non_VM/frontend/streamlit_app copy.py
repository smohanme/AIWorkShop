# frontend/streamlit_app.py
import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from backend.main import CoPilotInsurance
from backend.utils.collateral_generator import generate_collateral
from backend.utils.utils import push_to_crm

import streamlit as st
import os
from dotenv import load_dotenv

load_dotenv()
api_key = os.getenv("GROQ_API_KEY")

copilot = CoPilotInsurance(llm_api_key=api_key)

st.set_page_config(page_title="Insurance CoPilot", layout="wide")
st.title("Insurance Brokerage CoPilot")

customer_id = st.text_input("Enter Customer ID", value="CUST001")

if st.button("Run CoPilot"):
    if customer_id:
        st.subheader("Risk Profile Assessment")
        risk_output = copilot.assess_risk_profile(customer_id)
        st.write(risk_output)

        st.subheader("Product Recommendations")
        recommendation_output = copilot.recommend_products(customer_id)
        st.write(recommendation_output)

        st.subheader("Personalized Sales Collateral")
        collateral = copilot.generate_sales_collateral(customer_id, recommendation_output)
        st.json(collateral)
    else:
        st.warning("Please enter a valid Customer ID.")
