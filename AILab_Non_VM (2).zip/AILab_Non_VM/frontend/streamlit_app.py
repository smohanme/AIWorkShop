import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from backend.main import CoPilotInsurance
from dotenv import load_dotenv
import streamlit as st

# Load API key
load_dotenv()
api_key = os.getenv("GROQ_API_KEY")

# Initialize CoPilot
copilot = CoPilotInsurance(llm_api_key=api_key)

# Streamlit UI
st.set_page_config(page_title="Insurance CoPilot", layout="wide")
st.title("Insurance Brokerage CoPilot")

customer_id = st.text_input("Enter Customer ID", value="CUST001")

if st.button("Run CoPilot") and customer_id:
    # Risk Profile
    st.subheader("Risk Profile Assessment")
    risk_output = copilot.assess_risk_profile(customer_id)
    st.write(risk_output)

    # Product Recommendations
    st.subheader("Product Recommendations")
    recommendation_output = copilot.recommend_products(customer_id)
    st.write(recommendation_output)

    # # Personalized Sales Collateral
    # st.subheader("Personalized Sales Collateral")
    # collateral = copilot.generate_sales_collateral(customer_id, recommendation_output)
    # st.json(collateral)

    # Social Media Insights
    # st.subheader("Social Media Insights")
    # social_posts = copilot.retrieve_social_context(customer_id)
    # if social_posts:
    #     for post in social_posts:
    #         st.markdown(
    #             f"<div style='background:#f0f4c3;padding:0.5em 1em;border-radius:8px;margin-bottom:0.5em;color:#33691e;'>{post}</div>",
    #             unsafe_allow_html=True
    #         )
    # else:
    #     st.info("No social media posts found for this customer.")
else:
    if not customer_id:
        st.warning("Please enter a valid Customer ID.")
