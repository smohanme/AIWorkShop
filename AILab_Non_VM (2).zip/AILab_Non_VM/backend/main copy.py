# backend/main.py
import pandas as pd
import pickle
import faiss
from sentence_transformers import SentenceTransformer
from backend.gateway_client import GroqLLMClient
from backend.prompt_templates import risk_profile_prompt, product_recommendation_prompt
import os

class CoPilotInsurance:
    def __init__(self, llm_api_key: str = None):
        self.llm_client = GroqLLMClient(api_key=llm_api_key)
        MODEL_PATH = os.path.join(os.path.dirname(__file__), "models", "all-MiniLM-L6-v2.pt")
        self.model = SentenceTransformer(MODEL_PATH)
        self.index, self.meta = self.load_index()
        self.crm_data = pd.read_csv(os.path.join(os.path.dirname(__file__), "..", "data", "crm_data.csv"))
        self.risk_profile = pd.read_csv(os.path.join(os.path.dirname(__file__), "..", "data", "risk_profile.csv"))
        self.knowledge_base = pd.read_csv(os.path.join(os.path.dirname(__file__), "..", "data", "knowledge_base.csv"))
        self.social_media = pd.read_csv(os.path.join(os.path.dirname(__file__), "..", "data", "social_feeds.csv"))
        self.recommend_products_media = pd.read_csv(os.path.join(os.path.dirname(__file__), "..", "data", "product_recommendation.csv"))


    def load_index(self):
        index_path = os.path.join(os.path.dirname(__file__), "..", "index_store", "faiss.index")
        meta_path = os.path.join(os.path.dirname(__file__), "..", "index_store", "meta.pkl")
        index = faiss.read_index(index_path)
        with open(meta_path, "rb") as f:
            meta = pickle.load(f)
        return index, meta

    def retrieve_context(self, query: str, top_k: int = 3):
        embedding = self.model.encode([query])
        D, I = self.index.search(embedding, top_k)
        results = [self.meta[i] for i in I[0]]
        return results

    def assess_risk_profile(self, customer_id: str):
        customer = self.crm_data[self.crm_data["Customer_ID"] == customer_id].iloc[0].to_dict()
        age = customer['Age']
        filtered = self.risk_profile[self.risk_profile['Age_Range'].str.contains(str(age))]
        if filtered.empty:
            prompt = f"Provide a risk assessment for a {age}-year-old customer named {customer['Name']}."
            return self.llm_client.query(prompt)
        risk = filtered.iloc[0].to_dict()
        prompt = risk_profile_prompt(customer, risk)
        return self.llm_client.query(prompt)
    
    def retrieve_social_context(self, customer_id: str, top_k: int = 3):
        customer_posts = self.social_media[self.social_media['Customer_ID'] == customer_id]
        if customer_posts.empty:
            return []
        posts_text = customer_posts['Post_Content'].tolist()
        return posts_text[:top_k]

    def recommend_products(self, customer_id: str):
        customer = self.crm_data[self.crm_data["Customer_ID"] == customer_id].iloc[0].to_dict()
        kb_list = self.knowledge_base.to_dict(orient="records")
        prompt = product_recommendation_prompt(customer, kb_list)
        return self.llm_client.query(prompt)
    
    def recommend_products(self, customer_id: str):
        customer = self.crm_data[self.crm_data["Customer_ID"] == customer_id].iloc[0].to_dict()
        kb_list = self.knowledge_base.to_dict(orient="records")
        prompt = product_recommendation_prompt(customer, kb_list)
        return self.llm_client.query(prompt)

    def retrieve_product_recommendations_media(self, customer_id: str, top_k: int = 5):
        recommendations = self.recommend_products_media[
            self.recommend_products_media['Customer_ID'] == customer_id
        ]
        if recommendations.empty:
            return []
        return recommendations.to_dict(orient='records')[:top_k]


    def generate_sales_collateral(self, customer_id: str, recommendations: str):
        customer = self.crm_data[self.crm_data["Customer_ID"] == customer_id].iloc[0].to_dict()
        collateral = {
            "customer_name": customer['Name'],
            "recommendations": recommendations
        }
        return collateral
    
