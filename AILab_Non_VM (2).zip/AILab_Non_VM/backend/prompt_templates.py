def risk_profile_prompt(customer_profile: dict, risk_profile: dict) -> str:
    return f"""
You are a professional AI assistant for insurance brokers. Provide a structured risk assessment.

Customer Profile:
{customer_profile}

Risk Profile:
{risk_profile}

Instructions:
- Highlight key risks, risk rating, and mitigation strategies.
- Recommend suitable insurance product categories.
- Present output clearly and professionally.
"""

def product_recommendation_prompt(customer_profile: dict, knowledge_base: list) -> str:
    kb_text = "\n".join([f"{doc['Topic']}: {doc['Content']}" for doc in knowledge_base])
    return f"""
You are a professional AI insurance advisor. Recommend products based on:

Customer Profile:
{customer_profile}

Knowledge Base:
{kb_text}

Instructions:
- Recommend specific insurance products with reasoning.
- Link recommendations to customer's risk, occupation, income, and claims history.
- Present output in a clear, structured format.
"""
