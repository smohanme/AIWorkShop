#collateral_generator.py
import json

def generate_collateral(customer_info: dict, risk_profile: str, product_info: dict):
    collateral = {
        "customer_name": customer_info["Name"],
        "risk_profile": risk_profile,
        "recommended_product": product_info["Product_Name"],
        "coverage_details": {
            "type": product_info["Coverage_Type"],
            "premium": product_info["Premium_Range"]
        },
        "personalized_message": f"Based on your profile, {product_info['Product_Name']} is recommended.",
        "next_steps": "Schedule a call with your broker to finalize the plan."
    }
    return json.dumps(collateral, indent=4)
