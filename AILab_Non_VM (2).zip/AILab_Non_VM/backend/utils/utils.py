#backend/utils/utils.py
import pandas as pd

def push_to_crm(data: dict):
    """
    Push results to CRM system (via API)
    """
    # Placeholder: implement API integration
    print("Pushing data to CRM:", data)
    return True
