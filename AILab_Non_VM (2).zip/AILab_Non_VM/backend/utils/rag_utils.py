#backend/rag_utils.py
import pickle
import faiss
import pandas as pd
from sentence_transformers import SentenceTransformer

MODEL_NAME = "all-MiniLM-L6-v2"
embedding_model = SentenceTransformer(MODEL_NAME)

INDEX_FILE = "index_store/faiss.index"
META_FILE = "index_store/meta.pkl"

# Load FAISS index and metadata
def load_index():
    index = faiss.read_index(INDEX_FILE)
    with open(META_FILE, "rb") as f:
        meta = pickle.load(f)
    return index, meta

def embed_text(text: str):
    return embedding_model.encode([text], convert_to_numpy=True)

def retrieve_similar_documents(query: str, top_k=3):
    index, meta = load_index()
    query_vec = embed_text(query)
    D, I = index.search(query_vec, top_k)
    results = [meta[i] for i in I[0]]
    return results
