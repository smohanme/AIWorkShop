#/backend/gateway_client.py
import requests
import os
from dotenv import load_dotenv
import urllib3

urllib3.disable_warnings()  # Disable TLS warnings for testing

load_dotenv()

class GroqLLMClient:
    def __init__(self, api_key: str = None):
        if api_key is None:
            api_key = os.getenv("GROQ_API_KEY")
            if not api_key:
                raise ValueError("API key not provided in arguments or .env")
        self.api_key = api_key
        self.endpoint = "https://api.groq.com/openai/v1/chat/completions"
        self.headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }

    def query(self, prompt: str, model: str = "llama-3.3-70b-versatile") -> str:
        body = {
            "model": model,
            "messages": [{"role": "user", "content": prompt}]
        }
        response = requests.post(self.endpoint, headers=self.headers, json=body, verify=False)
        if response.status_code == 200:
            data = response.json()
            return data["choices"][0]["message"]["content"]
        else:
            return f"LLM API Error: {response.status_code} - {response.text}"
