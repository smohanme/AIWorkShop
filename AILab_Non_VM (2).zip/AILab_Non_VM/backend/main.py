import pandas as pd
import os
from sentence_transformers import SentenceTransformer
from backend.gateway_client import GroqLLMClient
from backend.prompt_templates import risk_profile_prompt, product_recommendation_prompt

class CoPilotInsurance:
    def __init__(self, llm_api_key: str = None):
        self.llm_client = GroqLLMClient(api_key=llm_api_key)

        # Load sentence-transformers model locally
        self.model = SentenceTransformer('backend/models/all-MiniLM-L6-v2.pt')  # or provide local path if downloaded

        # Load CSV data
        data_dir = os.path.join(os.path.dirname(__file__), '..', 'data')
        self.crm_data = pd.read_csv(os.path.join(data_dir, "crm_data.csv"))
        self.risk_profile = pd.read_csv(os.path.join(data_dir, "risk_profile.csv"))
        self.knowledge_base = pd.read_csv(os.path.join(data_dir, "knowledge_base.csv"))
        self.social_media = pd.read_csv(os.path.join(data_dir, "social_feeds.csv"))
        self.recommend_products_media = pd.read_csv(os.path.join(data_dir, "product_recommendation.csv"))

    def assess_risk_profile(self, customer_id: str):
        # Get customer info
        customer = self.crm_data[self.crm_data["Customer_ID"] == customer_id].iloc[0].to_dict()

        # Get risk profile
        filtered = self.risk_profile[self.risk_profile['Customer_ID'] == customer_id]
        if filtered.empty:
            prompt = f"Provide a risk assessment for a {customer['Age']}-year-old customer named {customer['Name']}."
            return self.llm_client.query(prompt)

        risk = filtered.iloc[0].to_dict()
        prompt = risk_profile_prompt(customer, risk)
        return self.llm_client.query(prompt)

    def recommend_products(self, customer_id: str):
        customer = self.crm_data[self.crm_data["Customer_ID"] == customer_id].iloc[0].to_dict()
        kb_list = self.knowledge_base.to_dict(orient="records")
        prompt = product_recommendation_prompt(customer, kb_list)
        return self.llm_client.query(prompt)

    def retrieve_social_context(self, customer_id: str, top_k: int = 3):
        posts = self.social_media[self.social_media['Customer_ID'] == customer_id]
        return posts['Post_Content'].tolist()[:top_k] if not posts.empty else []

    def retrieve_product_recommendations_media(self, customer_id: str, top_k: int = 5):
        recs = self.recommend_products_media[self.recommend_products_media['Customer_ID'] == customer_id]
        return recs.to_dict(orient='records')[:top_k] if not recs.empty else []

    def generate_sales_collateral(self, customer_id: str, recommendations):
        customer = self.crm_data[self.crm_data["Customer_ID"] == customer_id].iloc[0].to_dict()
        return {
            "customer_name": customer['Name'],
            "recommendations": recommendations
        }
