# rag/embeddings.py
from sentence_transformers import SentenceTransformer
import numpy as np

# Embedding model
EMBED_MODEL_NAME = "all-MiniLM-L6-v2"

_model = None

def get_model():
    """Load the embedding model (cached globally)."""
    global _model
    if _model is None:
        _model = SentenceTransformer(EMBED_MODEL_NAME)
    return _model

def embed_texts(texts):
    """Return numpy array of normalized embeddings for a list of texts."""
    model = get_model()
    emb = model.encode(texts, show_progress_bar=False, convert_to_numpy=True)
    # Normalize vectors for cosine similarity
    norms = np.linalg.norm(emb, axis=1, keepdims=True)
    norms[norms == 0] = 1.0
    return emb / norms

def embed_text(text):
    """Return embedding for a single text."""
    return embed_texts([text])[0]
