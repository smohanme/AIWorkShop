# rag/vectorstore.py
import os
from typing import List, Dict, Tuple
import numpy as np

# Try Milvus, else fallback to FAISS
USE_MILVUS = os.getenv("USE_MILVUS", "false").lower() == "true"

if USE_MILVUS:
    from pymilvus import (
        connections, FieldSchema, CollectionSchema,
        DataType, Collection, utility
    )

import faiss


class VectorStoreFAISS:
    def __init__(self, dim: int):
        self.dim = dim
        self.index = faiss.IndexFlatIP(dim)  # cosine similarity (requires normalized vectors)
        self.ids: List[str] = []
        self.metadatas: Dict[str, dict] = {}

    def add(self, ids: List[str], vectors: np.ndarray, metadatas: List[dict] = None):
        self.index.add(vectors)
        self.ids.extend(ids)
        if metadatas:
            for _id, md in zip(ids, metadatas):
                self.metadatas[_id] = md

    def search(self, query_vector: np.ndarray, top_k: int = 3) -> List[Tuple[str, float, dict]]:
        distances, indices = self.index.search(np.array([query_vector]), top_k)
        results = []
        for idx, score in zip(indices[0], distances[0]):
            if idx == -1:
                continue
            _id = self.ids[idx]
            md = self.metadatas.get(_id, {})
            results.append((_id, float(score), md))
        return results


def get_vectorstore(dim: int):
    """
    Factory function to get either Milvus or FAISS vectorstore.
    For simplicity, defaulting to FAISS unless USE_MILVUS=true is set.
    """
    if USE_MILVUS:
        raise NotImplementedError("Milvus integration not fully implemented in this demo.")
    else:
        return VectorStoreFAISS(dim)
