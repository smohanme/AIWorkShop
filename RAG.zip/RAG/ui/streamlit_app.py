# ui/streamlit_app.py
import requests
import streamlit as st
import os

API_URL = os.getenv("API_URL", "http://localhost:8000/query")

st.set_page_config(page_title="Insurance FAQ RAG Assistant", layout="centered")

st.title("💡 Insurance Policy FAQ RAG Assistant")
st.markdown("Ask any insurance-related question (auto/home). The assistant will answer using the FAQ knowledge base.")

question = st.text_input("Enter your question:")

if st.button("Ask") and question:
    with st.spinner("Thinking..."):
        try:
            resp = requests.post(API_URL, json={"question": question})
            resp.raise_for_status()
            data = resp.json()

            st.subheader("Answer:")
            st.write(data["answer"])

            st.subheader("Sources:")
            sources = [s for s in data["sources"] if s]  # remove None
            if sources:
                st.write(", ".join(sources))
            else:
                st.write("No sources available")

        except Exception as e:
            st.error(f"Error: {e}")
