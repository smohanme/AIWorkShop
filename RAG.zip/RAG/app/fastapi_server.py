# app/fastapi_server.py
import os
from fastapi import FastAPI  # pyright: ignore[reportMissingImports]
from pydantic import BaseModel  # pyright: ignore[reportMissingImports]
from business.retriever import FAQRetriever
from business.llm_gateway import query_llm

app = FastAPI(title="Insurance FAQ RAG Assistant")

# Load retriever at startup
retriever = FAQRetriever()


class QueryRequest(BaseModel):
    question: str


class QueryResponse(BaseModel):
    answer: str
    sources: list[str]


@app.post("/query", response_model=QueryResponse)
async def query_endpoint(req: QueryRequest):
    # Step 1: Retrieve FAQ context (top_k for richer context)
    context = retriever.build_context(req.question, top_k=3)

    # Step 2: Build prompt
    messages = [
        {
            "role": "system",
            "content": (
                "You are an insurance FAQ assistant. Use ONLY the provided FAQ context. "
                "If multiple FAQs are shown, pick the most relevant one to answer and more than 3 lines should be shown and clear to the user based on the questions being asked. "
                "Always cite the correct source ID clearly."
            ),
        },
        {
            "role": "user",
            "content": f"Question: {req.question}\n\nFAQ Context:\n{context}\n\nAnswer:",
        },
    ]

    # Step 3: Query LLM
    answer = await query_llm(messages)

    # Step 4: ✅ Fix sources — only take the *top-1 match* (most relevant)
    results = retriever.retrieve(req.question, top_k=3)
    final_sources = []
    if results:
        top_md = results[0][2]  # metadata from best match
        if top_md.get("source_id") and str(top_md["source_id"]).lower() != "nan":
            final_sources.append(top_md["source_id"])

    return QueryResponse(answer=answer, sources=final_sources)


if __name__ == "__main__":
    import uvicorn  # pyright: ignore[reportMissingImports]

    port = int(os.getenv("PORT", 8000))
    uvicorn.run("app.fastapi_server:app", host="0.0.0.0", port=port, reload=True)
