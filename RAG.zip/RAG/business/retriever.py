# business/retriever.py
import pandas as pd
from rag.embeddings import embed_text, embed_texts
from rag.vectorstore import get_vectorstore


class FAQRetriever:
    def __init__(self, faq_path: str = "data/faq.csv"):
        self.df = pd.read_csv(faq_path)

        # ✅ Clean source_id column (convert NaN/empty to None)
        if "source_id" in self.df.columns:
            self.df["source_id"] = self.df["source_id"].astype(str)
            self.df["source_id"] = self.df["source_id"].apply(
                lambda x: x.strip() if x and x.lower() != "nan" else None
            )

        self.vectorstore = None
        self._build_index()

    def _build_index(self):
        """Builds the vector index from the FAQ dataset."""
        questions = self.df["question"].tolist()
        answers = self.df["answer"].tolist()
        source_ids = self.df["source_id"].tolist()

        vectors = embed_texts(questions)
        self.vectorstore = get_vectorstore(vectors.shape[1])

        metadatas = [
            {"question": q, "answer": a, "source_id": sid}
            for q, a, sid in zip(questions, answers, source_ids)
        ]

        self.vectorstore.add(source_ids, vectors, metadatas)

    def retrieve(self, query: str, top_k: int = 3):
        """Returns top-k most relevant FAQ entries for a given query."""
        q_vec = embed_text(query)
        results = self.vectorstore.search(q_vec, top_k=top_k)

        # ✅ Only keep valid sources
        clean_results = []
        for _id, score, md in results:
            source = md.get("source_id")
            if source and str(source).lower() != "nan":
                clean_results.append((_id, score, md))

        return clean_results

    def build_context(self, query: str, top_k: int = 3):
        """Builds a context string from top-k matches for the LLM prompt."""
        matches = self.retrieve(query, top_k=top_k)
        if not matches:
            return "No relevant FAQ entries found."

        context_parts = []
        for _id, score, md in matches:
            source = md.get("source_id") or "Unknown Source"
            context_parts.append(
                f"Q: {md['question']}\nA: {md['answer']} [source: {source}]"
            )

        return "\n\n".join(context_parts)
