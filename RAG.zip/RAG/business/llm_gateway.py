# business/llm_gateway.py
import os
import httpx
from rich import print

# Groq API details
GROQ_API_URL = "https://api.groq.com/openai/v1/chat/completions"
GROQ_API_KEY = os.getenv("GROQ_API_KEY")

if not GROQ_API_KEY:
    print("[bold red]Warning:[/bold red] GROQ_API_KEY is not set in environment variables.")

DEFAULT_MODEL = "llama-3.3-70b-versatile"


async def query_llm(messages, model: str = DEFAULT_MODEL, temperature: float = 0.2):
    """
    Query the Groq LLM API.
    :param messages: List of dicts [{role: 'user'|'system'|'assistant', content: str}]
    :param model: Model name (default llama-3.3-70b-versatile)
    :param temperature: Sampling temperature
    :return: Response text from LLM
    """
    headers = {
        "Authorization": f"Bearer {GROQ_API_KEY}",
        "Content-Type": "application/json"
    }
    payload = {
        "model": model,
        "messages": messages,
        "temperature": temperature
    }

    async with httpx.AsyncClient(timeout=30.0) as client:
        resp = await client.post(GROQ_API_URL, headers=headers, json=payload)
        resp.raise_for_status()
        data = resp.json()

    try:
        return data["choices"][0]["message"]["content"].strip()
    except Exception as e:
        print(f"[red]Error parsing response:[/red] {e}")
        return "Sorry, I could not generate a response."
