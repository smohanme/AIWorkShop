import requests
res = requests.get("https://genailab.tcs.in/", verify=False)
print(res.status_code, res.text)