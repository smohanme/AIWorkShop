from fpdf import FPDF

pdf = FPDF()
pdf.add_page()
pdf.set_font("Arial", size=12)

lines = [
    "Insurance Claim Surveyor Report",
    "",
    "Policy Number: 1234567890",
    "Insured Name: John Doe",
    "Date of Loss: 2025-09-10",
    "Location: 123 Main Street, Springfield, USA",
    "",
    "Description of Incident:",
    "A severe thunderstorm caused a large tree to fall onto the insured's house, resulting in significant roof and structural damage.",
    "",
    "Estimated Damage Cost: $18,500",
    "",
    "Surveyor Observations:",
    "- Roof collapsed in two rooms.",
    "- Water leakage observed in the living area.",
    "- No injuries reported.",
    "",
    "Cause of Loss: Storm (Fallen Tree)",
    "",
    "Recommended Next Action:",
    "- Immediate temporary repairs to prevent further water ingress.",
    "- Obtain quotes from licensed contractors for permanent repairs.",
    "- Review policy coverage for storm-related damages.",
    "",
    "Surveyor Name: Jane Smith",
    "Date of Survey: 2025-09-12"
]

for line in lines:
    pdf.cell(0, 10, line, ln=1)

pdf.output("y:/Hackathon/Chennai/Siruseri/team20/Demo1/sample_claim.pdf")
