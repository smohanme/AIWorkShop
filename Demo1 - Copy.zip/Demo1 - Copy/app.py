import streamlit as st
import tempfile
import os
import openai
import json
import httpx
import requests
import pandas as pd

st.set_page_config(page_title="CoPilot for Insurance Brokerage Agencies", layout="wide")

# --- Enhanced UI Styling ---
import streamlit.components.v1 as components
st.markdown(
    """
    <style>
    .main-title {
        font-size: 2.8rem;
        font-weight: 800;
        color: #0d47a1;
        margin-bottom: 0.3rem;
        letter-spacing: 2px;
        font-family: 'Segoe UI', 'Arial', sans-serif;
    }
    .subtitle {
        font-size: 1.25rem;
        color: #1976d2;
        margin-bottom: 2.2rem;
        font-family: 'Segoe UI', 'Arial', sans-serif;
    }
    .stButton > button {
        background: linear-gradient(90deg, #1976d2 0%, #64b5f6 100%);
        color: white;
        font-weight: 700;
        border-radius: 8px;
        padding: 0.7rem 2rem;
        margin-top: 1rem;
        font-size: 1.1rem;
        box-shadow: 0 2px 8px rgba(25, 118, 210, 0.08);
        border: none;
        transition: background 0.3s;
    }
    .stButton > button:hover {
        background: linear-gradient(90deg, #1565c0 0%, #90caf9 100%);
    }
    .stTextInput, .stTextArea, .stSelectbox {
        border-radius: 8px;
        border: 1.5px solid #1976d2;
        font-size: 1.08rem;
        font-family: 'Segoe UI', 'Arial', sans-serif;
        background-color: #f5faff;
    }
    .stSidebar {
        background-color: #e3f2fd;
    }
    .stMarkdown {
        font-size: 1.13rem;
        color: #263238;
        font-family: 'Segoe UI', 'Arial', sans-serif;
    }
    .stHeader {
        color: #1976d2;
        font-size: 1.5rem;
        font-weight: 700;
        margin-bottom: 1.2rem;
        font-family: 'Segoe UI', 'Arial', sans-serif;
    }
    .stSubheader {
        color: #0d47a1;
        font-size: 1.2rem;
        font-weight: 600;
        margin-bottom: 0.8rem;
        font-family: 'Segoe UI', 'Arial', sans-serif;
    }
    .stTable, .stDataFrame {
        background-color: #e3f2fd;
        border-radius: 8px;
        font-size: 1.05rem;
    }
    .stSelectbox label {
        color: #1976d2;
        font-weight: 600;
    }
    .stTextArea label {
        color: #1976d2;
        font-weight: 600;
    }
    .stTextInput label {
        color: #1976d2;
        font-weight: 600;
    }
    .stSpinner > div {
        color: #1976d2 !important;
    }
    .stAlert {
        background-color: #fffde7;
        color: #f57c00;
        border-radius: 8px;
        font-size: 1.08rem;
    }
    </style>
    """,
    unsafe_allow_html=True
)

st.sidebar.image("https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=400&q=80", use_container_width=True)
st.sidebar.title("Navigation")
page = st.sidebar.radio("Go to", ("Home", "Chatbot", "Customer Profile", "Sales Collateral", "About", "Contact"))

# Language selection dropdown (global)
languages = {
    "English": "en",
    "Hindi": "hi",
    "Tamil": "ta",
    "Spanish": "es",
    "French": "fr"
}
if "chatbot_language" not in st.session_state:
    st.session_state["chatbot_language"] = "en"
selected_lang = st.sidebar.selectbox("Select language for responses:", list(languages.keys()), index=list(languages.values()).index(st.session_state["chatbot_language"]))
st.session_state["chatbot_language"] = languages[selected_lang]

st.markdown("""
<div style='width:100%;background:linear-gradient(90deg,#1976d2 0%,#64b5f6 100%);padding:1.5rem 0;margin-bottom:1.5rem;border-radius:12px;box-shadow:0 2px 8px rgba(25,118,210,0.10);text-align:center;'>
    <span style='font-size:2.5rem;font-weight:900;color:#fff;letter-spacing:2px;font-family:Segoe UI,Arial,sans-serif;'>CoPilot for Insurance Brokerage Agencies</span>
</div>
""", unsafe_allow_html=True)
st.markdown("<div class='subtitle'>Empowering brokers with AI-driven customer engagement and sales</div>", unsafe_allow_html=True)

# --- utils.py ---
# Utility functions for data loading, responsible AI checks
# (Synthetic data generation removed; handled in generate_synthetic_csv.py)

def load_csv(path):
    return pd.read_csv(path)

def mask_sensitive_data(data):
    # Mask PII fields for data protection
    masked = data.copy()
    if "name" in masked:
        masked["name"] = masked["name"][0] + "***"  # Only show first letter
    if "location" in masked:
        masked["location"] = "[REDACTED]"
    return masked

def check_bias_in_recommendation(recommendation, products):
    # Simple fairness check: ensure all product types are recommended over time
    # (In production, use more advanced fairness metrics)
    types = set(p["type"] for p in products)
    for t in types:
        if t in recommendation:
            return True
    return False

def responsible_ai_notice():
    st.info("This AI agent is designed for responsible use. Customer data is masked, recommendations are checked for fairness, and all interactions are logged for audit.")

# --- LiteLLM/OpenAI Proxy Setup ---
LITELLM_URL = "https://genailab.tcs.in/v1/chat/completions"
API_KEY = st.secrets["LITELLM_API_KEY"] if "LITELLM_API_KEY" in st.secrets else "sk-9Iuu7yap97VGk9mYCVa4pw"
MODEL_NAME = "azure/genailab-maas-gpt-4o"

# Helper for LiteLLM chat completions

def lite_llm_chat(prompt, max_tokens=256):
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json"
    }
    data = {
        "model": MODEL_NAME,
        "messages": [{"role": "user", "content": prompt}],
        "max_tokens": max_tokens
    }
    try:
        res = requests.post(LITELLM_URL, headers=headers, json=data, verify=False)
        if res.status_code == 200:
            return res.json()["choices"][0]["message"]["content"]
        else:
            return f"Error: {res.status_code} {res.text}"
    except Exception as e:
        return f"Connection error: {e}"

# --- Main App Logic ---
responsible_ai_notice()

if page == "Chatbot":
    st.header("Multi-lingual Chatbot & Knowledge Base")
    st.markdown("<div style='font-size:1.2rem;color:#1976d2;font-weight:600;'>👋 Welcome! I'm your friendly insurance assistant. Let's get to know you before we chat!</div>", unsafe_allow_html=True)
    # Step 1: Collect user info
    with st.form("user_info_form"):
        name = st.text_input("What's your name?")
        age = st.number_input("How old are you?", min_value=1, max_value=120, step=1)
        location = st.text_input("Where are you located?")
        languages = {
            "English": "en",
            "Hindi": "hi",
            "Tamil": "ta",
            "Spanish": "es",
            "French": "fr"
        }
        selected_lang = st.selectbox("Preferred language for conversation:", list(languages.keys()))
        submitted = st.form_submit_button("Start Chat")
    if submitted and name and location:
        # Load existing customer profiles from CSV
        try:
            if os.path.exists("customer_profiles.csv"):
                customers = load_csv("customer_profiles.csv").to_dict(orient="records")
            else:
                customers = []
            # Generate a new unique id
            new_id = f"C{len(customers)+1:04d}"
            user_info = {
                "id": new_id,
                "name": name,
                "age": age,
                "location": location,
                "policy": "Not set",
                "history": "New user"
            }
            customers.append(user_info)
            pd.DataFrame(customers).to_csv("customer_profiles.csv", index=False)
        except Exception as e:
            st.warning(f"Could not save user info to customer_profiles.csv: {e}")
        # Store user info in backend CSV file
        try:
            if os.path.exists("user_data.csv"):
                all_users = load_csv("user_data.csv").to_dict(orient="records")
            else:
                all_users = []
            all_users.append(user_info)
            pd.DataFrame(all_users).to_csv("user_data.csv", index=False)
        except Exception as e:
            st.warning(f"Could not save user info: {e}")
        st.success(f"Thanks {name}! Let's start our conversation in {selected_lang}.")
        st.session_state["chatbot_language"] = languages[selected_lang]
        st.session_state["user_info"] = user_info
    # Step 2: Chat interface (only after user info is submitted)
    if "user_info" in st.session_state:
        user_info = st.session_state["user_info"]  # Fix: retrieve user_info from session state
        query = st.text_input(f"Ask a question (in {selected_lang}):")
        if query:
            with open("knowledge_base.txt", "r", encoding="utf-8") as f:
                kb_text = f.read()
            prompt = f"You are a lively, friendly insurance chatbot. Respond in {selected_lang} language. User info: {json.dumps(user_info)}.\nQuery: {query}\nContext: {kb_text}"
            with st.spinner("Thinking..."):
                answer = lite_llm_chat(prompt, max_tokens=256)
            st.write("**Answer:**", answer)

elif page == "Customer Profile":
    st.header("Customer Profile Lookup & Risk Analysis")
    customers = load_csv("customer_profiles.csv")
    customer_names = customers["name"].tolist()
    selected = st.selectbox("Select Customer", customer_names)
    customer = customers[customers["name"] == selected].iloc[0].to_dict()
    masked_customer = mask_sensitive_data(customer)
    st.write("**Profile (PII masked):**", masked_customer)
    feeds = load_csv("customer_social_feeds.csv")
    feed_row = feeds[feeds["id"] == customer["id"]]
    feed = feed_row["feed"].iloc[0] if not feed_row.empty else "No social feed available."
    st.write("**Social Feed:**", feed)
    risk_segments = load_csv("risk_segments.csv").to_dict(orient="records")
    risk_prompt = f"Given the following customer profile and social feed, classify the risk profile. Respond in {selected_lang} language.\nProfile: {json.dumps(masked_customer)}\nFeed: {feed}\nSegments: {json.dumps(risk_segments)}"
    with st.spinner("Identifying risk profile..."):
        risk = lite_llm_chat(risk_prompt, max_tokens=128)
    st.write("**Risk Profile:**", risk)
    products = load_csv("products.csv").to_dict(orient="records")
    rec_prompt = f"Based on the customer profile and risk, recommend the best fit insurance product. Respond in {selected_lang} language.\nProfile: {json.dumps(masked_customer)}\nRisk: {risk}\nProducts: {json.dumps(products)}"
    with st.spinner("Recommending product..."):
        recommendation = lite_llm_chat(rec_prompt, max_tokens=128)
    if not check_bias_in_recommendation(recommendation, products):
        st.warning("Recommendation fairness check failed. Please review product options.")
    st.write("**Recommended Product:**", recommendation)

elif page == "Sales Collateral":
    st.header("Generate Personalized Sales Collateral")
    customers = load_csv("customer_profiles.csv")
    customer_names = customers["name"].tolist()
    selected = st.selectbox("Select Customer for Collateral", customer_names)
    customer = customers[customers["name"] == selected].iloc[0].to_dict()
    masked_customer = mask_sensitive_data(customer)
    products = load_csv("products.csv").to_dict(orient="records")
    collateral_prompt = f"Generate a personalized sales collateral for the following customer, including their risk profile and recommended product. Respond in {selected_lang} language.\nCustomer: {json.dumps(masked_customer)}\nProducts: {json.dumps(products)}"
    if st.button("Generate Collateral"):
        with st.spinner("Generating sales collateral..."):
            collateral = lite_llm_chat(collateral_prompt, max_tokens=256)
        st.write("**Sales Collateral:**", collateral)
    responsible_ai_notice()

elif page == "About":
    st.header("About CoPilot for Insurance Brokerage Agencies")
    st.write("This AI agent helps brokers deliver personalized customer experiences, recommend products, and generate sales collateral using customer data, social feeds, and knowledge base documents.")

elif page == "Contact":
    st.header("Contact")
    st.write("Contact us at: demo@example.com")
