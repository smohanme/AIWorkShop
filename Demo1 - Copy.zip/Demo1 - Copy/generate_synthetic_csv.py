import pandas as pd
import random

# Generate synthetic customer profiles for Life Insurance only
first_names = ["Alice", "Bob", "Carlos", "Priya", "John", "Mei", "Sarah", "David", "Fatima", "Liam", "Emma", "Noah", "Olivia", "Ava", "Sophia", "Mason", "Lucas", "Ethan", "Isabella", "Mia"]
last_names = ["Smith", "Lee", "Ruiz", "Kumar", "Miller", "Wong", "Johnson", "Brown", "Patel", "Kim", "Singh", "Garcia", "Martinez", "Chen", "Williams", "Davis", "Rodriguez", "Lopez", "Clark", "Lewis"]
locations = ["New York", "California", "Texas", "Chennai", "London", "Singapore", "Sydney", "Toronto", "Berlin", "Paris", "Mumbai", "Delhi", "Dubai", "Tokyo", "Cape Town", "Melbourne", "Chicago", "Los Angeles", "Madrid", "Rome"]
histories = ["No claims", "1 claim", "2 claims", "Multiple claims", "New user"]

customers = []
for i in range(1, 1001):
    fname = random.choice(first_names)
    lname = random.choice(last_names)
    name = f"{fname} {lname}"
    age = random.randint(18, 70)
    location = random.choice(locations)
    policy = "Life"
    history = random.choice(histories)
    customers.append({
        "id": f"C{i:04d}",
        "name": name,
        "age": age,
        "location": location,
        "policy": policy,
        "history": history
    })
pd.DataFrame(customers).to_csv("customer_profiles.csv", index=False)

# Generate synthetic customer social feeds for Life Insurance
social_feeds = []
for c in customers:
    feed = f"{c['name'].split()[0]} shares updates about {random.choice(['life insurance tips', 'family protection', 'financial planning', 'community events', 'wellness', 'long-term savings'])}."
    social_feeds.append({"id": c["id"], "feed": feed})
pd.DataFrame(social_feeds).to_csv("customer_social_feeds.csv", index=False)

# Generate synthetic products for Life Insurance only
products = [
    {"name": "Life Secure", "type": "Life", "features": "Term life, whole life, family protection, savings"},
    {"name": "Family Shield", "type": "Life", "features": "Comprehensive family coverage, accidental death benefit"},
    {"name": "Retirement Plus", "type": "Life", "features": "Retirement planning, annuity options, long-term savings"}
]
pd.DataFrame(products).to_csv("products.csv", index=False)

# Generate synthetic risk segments for Life Insurance
risk_segments = [
    {"segment": "Low", "criteria": "No claims, healthy lifestyle, non-smoker"},
    {"segment": "Medium", "criteria": "Some claims, average health, occasional smoker"},
    {"segment": "High", "criteria": "Multiple claims, chronic illness, smoker"}
]
pd.DataFrame(risk_segments).to_csv("risk_segments.csv", index=False)

print("Synthetic CSV data generated for Life Insurance only: customer_profiles, customer_social_feeds, products, and risk_segments.")
