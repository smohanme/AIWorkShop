import os
os.environ["SSL_CERT_FILE"] = r"Y:\Hackathon\Chennai\Siruseri\team20\Demo1\cacert.pem"
import requests
print(requests.get("https://www.google.com").status_code)