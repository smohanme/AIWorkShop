# AI Insurance FAQ RAG Project

## Prerequisites
- Python 3.8+
- pip

## Installation
1. Open a terminal in the project root (`D:\AI_Workspace\AILab_Non_VM`).
2. Install required packages:
   ```powershell
   pip install -r requirements.txt
   pip install -r frontend/requirements.txt
   pip install faiss-cpu streamlit python-dotenv
   ```

## Running the Backend (FastAPI)
1. In the project root, run:
   ```powershell
   python -m backend.main
   ```
2. The API will be available at: [http://127.0.0.1:8000](http://127.0.0.1:8000)

## Running the Frontend (Streamlit)
1. Open a new terminal in the project root.
2. Run:
   ```powershell
   streamlit run frontend/streamlit_app.py
   ```
3. The app will open in your browser.

## Notes
- Ensure `data/faqs.csv` exists for default ingestion.
- If you encounter missing package errors, install them using `pip install <package-name>`.

## Project Structure
- `backend/` - FastAPI backend scripts
- `frontend/` - Streamlit frontend app
- `data/` - CSV data files
- `index_store/` - Index files

---
For any issues, check the terminal output for error messages and ensure all dependencies are installed.

## Installed Python Packages

Below is a list of all Python packages installed for this project, with their versions:

```text
altair (5.5.0)
attrs (25.3.0)
blinker (1.9.0)
cachetools (6.2.0)
certifi (2025.8.3)
charset-normalizer (3.4.3)
click (8.3.0)
colorama (0.4.6)
faiss-cpu (1.12.0)
gitdb (4.0.12)
GitPython (3.1.45)
idna (3.10)
Jinja2 (3.1.6)
jsonschema (4.25.1)
jsonschema-specifications (2025.9.1)
MarkupSafe (3.0.2)
narwhals (2.5.0)
numpy (2.3.3)
packaging (25.0)
pandas (2.3.2)
pillow (11.3.0)
pip (25.1.1)
protobuf (6.32.1)
pyarrow (21.0.0)
pydeck (0.9.1)
python-dateutil (2.9.0.post0)
python-dotenv (1.0.1)
pytz (2025.2)
referencing (0.36.2)
requests (2.32.5)
rpds-py (0.27.1)
six (1.17.0)
smmap (5.0.2)
streamlit (1.50.0)
tenacity (9.1.2)
toml (0.10.2)
tornado (6.5.2)
typing_extensions (4.15.0)
tzdata (2025.2)
urllib3 (2.5.0)
watchdog (6.0.0)
```
