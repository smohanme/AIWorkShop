# backend/retriever.py
import numpy as np
from sentence_transformers import SentenceTransformer
import faiss
import pickle
import os

MODEL_NAME = "all-MiniLM-L6-v2"

class Retriever:
    def __init__(self, index_dir="./index_store"):
        self.index_dir = index_dir
        self.index_path = os.path.join(self.index_dir, "faiss.index")
        self.meta_path = os.path.join(self.index_dir, "meta.pkl")
        self.model = SentenceTransformer(MODEL_NAME)
        self.index = None
        self.metadata = []
        self.load()

    def load(self):
        if os.path.exists(self.index_path) and os.path.exists(self.meta_path):
            self.index = faiss.read_index(self.index_path)
            with open(self.meta_path, "rb") as f:
                self.metadata = pickle.load(f)
        else:
            raise FileNotFoundError("Index or metadata not found. Please run ingestion first.")

    def _normalize(self, v):
        n = np.linalg.norm(v) + 1e-10
        return v / n

    def search(self, query: str, top_k: int = 3):
        q_emb = self.model.encode([query], convert_to_numpy=True)[0]
        q_emb = self._normalize(q_emb).astype('float32')
        D, I = self.index.search(q_emb.reshape(1, -1), top_k)
        results = []
        for score, idx in zip(D[0], I[0]):
            if idx < 0 or idx >= len(self.metadata):
                continue
            meta = self.metadata[idx]
            results.append({
                "id": meta["id"],
                "score": float(score),
                "question": meta["question"],
                "answer": meta["answer"],
                "source": meta["source"]
            })
        return results
