# backend/indexer.py
import os
import pandas as pd
import numpy as np
from sentence_transformers import SentenceTransformer
import faiss
import pickle

MODEL_NAME = "all-MiniLM-L6-v2"  # compact, fast
EMB_DIM = 384  # model output dim for all-MiniLM-L6-v2

class Indexer:
    def __init__(self, index_dir="./index_store"):
        self.index_dir = index_dir
        os.makedirs(self.index_dir, exist_ok=True)
        self.model = SentenceTransformer(MODEL_NAME)
        self.index_path = os.path.join(self.index_dir, "faiss.index")
        self.meta_path = os.path.join(self.index_dir, "meta.pkl")
        self.index = None
        self.metadata = []

    def _normalize(self, vectors: np.ndarray):
        norms = np.linalg.norm(vectors, axis=1, keepdims=True) + 1e-10
        return vectors / norms

    def build_index_from_csv(self, csv_path: str):
        df = pd.read_csv(csv_path)
        docs = []
        for _, row in df.iterrows():
            doc_text = f"Q: {row['question']}\nA: {row['answer']}"
            docs.append(doc_text)
        embeddings = self.model.encode(docs, convert_to_numpy=True, show_progress_bar=True)
        embeddings = self._normalize(embeddings)

        # build faiss index (cosine similarity via inner product on normalized vectors)
        dim = embeddings.shape[1]
        index = faiss.IndexFlatIP(dim)
        index.add(embeddings.astype('float32'))

        # metadata list (id and text and original fields)
        metadata = []
        for i, (_, row) in enumerate(df.iterrows()):
            metadata.append({
                "id": int(row['id']),
                "question": row['question'],
                "answer": row['answer'],
                "source": f"{os.path.basename(csv_path)}#row{i+1}"
            })

        # save index and metadata
        faiss.write_index(index, self.index_path)
        with open(self.meta_path, "wb") as f:
            pickle.dump(metadata, f)

        self.index = index
        self.metadata = metadata
        return {"indexed": len(metadata), "index_path": self.index_path, "meta_path": self.meta_path}

    def load_index(self):
        if os.path.exists(self.index_path) and os.path.exists(self.meta_path):
            self.index = faiss.read_index(self.index_path)
            with open(self.meta_path, "rb") as f:
                self.metadata = pickle.load(f)
            return True
        return False
