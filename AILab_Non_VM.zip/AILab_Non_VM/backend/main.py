# backend/main.py
import os
from fastapi import FastAPI, UploadFile, File
from pydantic import BaseModel
import shutil
from dotenv import load_dotenv
from backend.indexer import Indexer
from backend.retriever import Retriever
from backend.groq_client import GroqClient
from backend.prompt_templates import build_prompt

load_dotenv()
app = FastAPI(title="Insurance FAQ RAG - Business Layer")

INDEX_DIR = os.getenv("INDEX_DIR", "./index_store")
DATA_DIR = "./data"
os.makedirs(DATA_DIR, exist_ok=True)
indexer = Indexer(index_dir=INDEX_DIR)
groq = GroqClient()

class QueryRequest(BaseModel):
    query: str
    top_k: int = 3
    model: str = "llama-3.3-70b-versatile"

@app.post("/ingest_csv")
async def ingest_csv(file: UploadFile = File(...)):
    target_path = os.path.join(DATA_DIR, file.filename)
    with open(target_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    res = indexer.build_index_from_csv(target_path)
    return {"status": "ok", "details": res}

@app.post("/ingest_default")
def ingest_default():
    csv_path = os.path.join(DATA_DIR, "faqs.csv")
    if not os.path.exists(csv_path):
        return {"error": "default faqs.csv not found in data/; put CSV in data/faqs.csv or use /ingest_csv"}
    res = indexer.build_index_from_csv(csv_path)
    return {"status": "ok", "details": res}

@app.post("/query")
def query(req: QueryRequest):
    # load retriever
    retriever = Retriever(index_dir=INDEX_DIR)
    docs = retriever.search(req.query, top_k=req.top_k)
    messages = build_prompt(req.query, docs)
    # call groq
    content = groq.chat_completion(messages=messages, model=req.model)
    return {"answer": content, "retrieved": docs}

@app.get("/status")
def status():
    loaded = indexer.load_index()
    return {"index_loaded": loaded, "indexed_docs": len(indexer.metadata) if loaded else 0}


# Add server startup for FastAPI
if __name__ == "__main__":
    import uvicorn
    uvicorn.run("backend.main:app", host="127.0.0.1", port=8000, reload=True)
